Salve prof,
il file che si chiama mavenproject4 contiene il progetto completo fatto con NetBeans, perché non riesco trasformare il file .java a file.jar, ma il progetto funziona correttamente su NetBeans,

Mi scuso per il disagio.

Jennifer Sculco