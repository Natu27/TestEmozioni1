/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;


public class Clienti {

    /**
     * Crea un oggetto della classe MyFrameC e ne
     * imposta la visibilità a true
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyFrameC mfc = new MyFrameC();
        mfc.setVisible(true);
    }
    
}
