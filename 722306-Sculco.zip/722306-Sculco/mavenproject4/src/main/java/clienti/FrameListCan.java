/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * Permette di selezionare una canzone tra quelle
 * ottenute mediante una funzione di ricerca.
 * Inoltre, se l'utente si è registrato, permette
 * di scegliere se visualizzare le informazioni
 * relative alla canzone selezionato o giudicare
 * tale canzone.
 */
public class FrameListCan extends JFrame{
    
    JButton jb;
    JPanel jp;
    
    /**
     * Contiene tutti gli elementi da visualizzare e definisce le
     * caratteristiche della schermata.
     * 
     * @param arl ArrayList contenente tutti i bottoni ottenuti dalla ricerca
     * @param nick nickname dell'utente registrato (null in caso di accesso libero)
     * @param acc valore booleano per verificare se l'accesso è stato eseguito
     */
    public FrameListCan(ArrayList<JButton> arl, String nick, boolean acc) {
        super("Selezione canzone");
        this.setSize(550, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        String[] jc_itemsSel = {"Vedi info", "Giudica", "Crea playlist"}; 
        
        JComboBox jc_Sel = new JComboBox(jc_itemsSel);   
        
        if (acc == false) {
            jc_Sel.setEnabled(false);
            jc_Sel.setVisible(false);
        }
        
        add(jc_Sel, BorderLayout.NORTH);
        
        String user = nick;
        jp = new JPanel(new GridLayout(arl.size()/2, 2, 5,5));
        jp.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        for (int i = 0; i < arl.size(); i++) {
            jb = arl.get(i);
            jp.add(jb);
        }
        
        JScrollPane jsp = new JScrollPane(jp, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        
        add(jsp, BorderLayout.CENTER);
        
        for (int i = 0; i < arl.size(); i++) {
            JButton jtmp = (JButton)jp.getComponent(i);
            jtmp.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String[] split_btn = jtmp.getText().split(" ");
                    
                    if (jc_Sel.getSelectedItem().toString().equalsIgnoreCase("Giudica")) {
                        FrameGiud fg = new FrameGiud(user, split_btn[1], split_btn[0]);
                        fg.setVisible(true);
                    }
                    
                    if (jc_Sel.getSelectedItem().toString().equalsIgnoreCase("Vedi info")) {
                        FrameInfo fi = new FrameInfo(split_btn[0]);
                        fi.setVisible(true);
                    }
                    
                    if (jc_Sel.getSelectedItem().toString().equalsIgnoreCase("Crea playlist")) {
                        Crea cr = new Crea (user, split_btn[1], split_btn[0]);
                        
                    }
                }
            });
        }
    }
    
}
