/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.MouseInputListener;

/**
 *
 * Permette di ricercare i nomi delle canzoni mediante
 * l'inserimento del autore, del anno,
 * entrambi o di una parte del titolo.
 */
public class FrameRicerca extends JFrame{
    
    BufferedReader bf;
    String row;
    String[] split;
    
    /**
     * Contiene tutte le componenti da visualizzare e definisce 
     * alcune proprietà della schermata come titolo e dimensione
     */
    public FrameRicerca() {
        super("Ricerca canzoni");
        this.setSize(550, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        JLabel jl_tip = new JLabel("Scegli il tipo di ricerca: ");
        
        String[] jc_items = {"titolo","autore e anno"};
        JComboBox jc = new JComboBox(jc_items);
        
        JLabel jl_ric = new JLabel("Inserisci il termine di ricerca: ");
        
        JTextField jtf_ric = new RoundJtextField();
        jtf_ric.setHorizontalAlignment(SwingConstants.CENTER);
        jtf_ric.addMouseListener(new MouseInputListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (jc.getSelectedItem().toString().equals("autore e anno")) {
                    JOptionPane.showMessageDialog(getContentPane(), "Inserire prima il autore e poi la anno separati da una virgola e senza spazi");
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseExited(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        
        
        JButton jb_cerca = new JButton("cerca");
        jb_cerca.setCursor(new Cursor(12));
        
        
        JPanel jp = new JPanel();
        jp.setLayout(new BoxLayout(jp, BoxLayout.X_AXIS));
        jp.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        jp.add(jl_ric);
        jp.add(jtf_ric);
        
        JPanel jp2 = new JPanel();
        jp2.setLayout(new BoxLayout(jp2, BoxLayout.X_AXIS));
        jp2.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        jp2.add(jl_tip);
        jp2.add(jc);
        
        JPanel jp3 = new JPanel();
        jp3.setLayout(new BoxLayout(jp3, BoxLayout.Y_AXIS));
        jp3.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));
        jp3.add(jp2);
        jp3.add(jp);
        jp3.add(jb_cerca);
        
        
        JTextArea jta_ris = new JTextArea();
        jta_ris.setEditable(false);
        jta_ris.setText("Nomi dei canzoni trovati: \n");
        
        JScrollPane jsp = new JScrollPane(jta_ris, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        jsp.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));
        
        
        jb_cerca.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jtf_ric.getText().equals("")) {
                    JOptionPane.showMessageDialog(getContentPane(), "campo mancante");
                } else {
                    String tip = jc.getSelectedItem().toString();
                    String ter = jtf_ric.getText();
                    jta_ris.setText("Titoli dei canzoni trovati: \n");
                    
                    File f = new File("data/Canzoni.dati");
                    
                    if (!f.exists()) {
                        System.err.println("IL FILE NON  ESISTE");
                    }
                    
                    try {
                        bf = new BufferedReader(new FileReader(f));
                    } catch (FileNotFoundException ex) {
                        System.err.println("ERRORE " + ex);
                    }
                    
                    while (true) {
                        try {
                            row = bf.readLine();
                            split = row.split("/");
                            
                            if (tip.equals("titolo")) { 
                                if (split[3].contains(ter) && !ter.equals("") && !split[0].equals("Giudizio")) {
                                    jta_ris.setText(jta_ris.getText() + split[3] + "\n");
                                }
                            } else if (tip.equals("autore e anno")) {
                                String[] terSplit = ter.split(",");
                                
                                if (split[2].equalsIgnoreCase(terSplit[0]) &&
                                        split[0].equalsIgnoreCase(terSplit[1]) &&
                                        (!terSplit[0].equals("") || !terSplit[1].equals(""))) {
                                    
                                    jta_ris.setText(jta_ris.getText() + split[3] + "\n");
                                }
                            }
                        } catch (IOException ex) {
                            System.err.println("ERRORE " + ex);
                            break;
                        } catch (NullPointerException ex) {
                            System.err.println("ERRORE " + ex);
                            break;
                        }
                    }
                }
            }
        });
        
        
        add(jsp, BorderLayout.CENTER);
        
        add(jp3, BorderLayout.NORTH);
        
        
        
        
    }
    
}
