/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPasswordField;
/**
 *
 * Ridefinisce la forma delle JPasswordField
 * rendendole arrotondate ai bordi 
 * invece che squadrate
 * 
 * @version 1.0
 * @author Jennifer Sculco 722306 Varese
 */
public class RoundPassField extends JPasswordField {
    
    /**
     * Imposta l'opacità a false
     */
    public RoundPassField() {
        setOpaque(false); 
    }
    
    /**
     * Sovrascrive il metodo paintComponent della
     * classe JTextField
     * 
     * @param g la componente grafica
     */
    protected void paintComponent(Graphics g) {
         g.setColor(getBackground());
         g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 40, 40);
         super.paintComponent(g);
    }
    
    /**
     * Sovrascrive il metodo paintBorder della
     * classe JTextField
     * 
     * @param g il contesto grafico nel quale "disegnare"
     */
    protected void paintBorder(Graphics g) {
         g.setColor(Color.CYAN);
         g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 40, 40);
    }
    
}
