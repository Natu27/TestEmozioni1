/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;


public class Crea extends JFrame {

    BufferedReader bf;
    String row;
    String[] split;
    int i = 1;
    int[] vett_voti = {0,0,0,0,0};
    

    Crea(String nick, String nCan, String pCan) {
        
        super("Aggiunggi Canzone al playlist");
        this.setSize(550, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        String user = nick;
        
        JButton jb = new JButton("Salva canzone");
        
        JPanel jp3 = new JPanel();
        jp3.setBorder(BorderFactory.createEmptyBorder(0, 50, 10, 50));
        jp3.add(jb);
        
           /*     jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File f = new File("data/Playlist.dati");
                
                if (!f.exists()) {
                    System.err.println("IL FILE NON ESISTE");
                }
                
                Path p = Paths.get("data/Playlist.dati");
                try {
                    
                    Files.write(p, "Playlist".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, pCan.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, nCan.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, user.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "\n".getBytes(), StandardOpenOption.APPEND);
                    
                } catch (IOException ex) {
                    System.err.println("ERRORE " + ex);
                }
            }
        });*/
        
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
