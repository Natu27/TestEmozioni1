/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;

/**
 *
 * Permette di scegliere quale operazione eseguire;
 * se ricercare una canzone, se vederne le info
 * o, se si è registrati, giudicarla.
 */
public class FrameSel extends JFrame{
    
    /**
     * Contiene tutti gli elementi da visualizzare e 
     * definisce alcune caratteristiche della schermata
     * 
     * @param acc booleano utilizzato per verificare l'avvenuto accesso
     * e nel caso abilitare il bottone giudica
     * @param nick nickname dell'utente che vuole giudicare una canzone
     * (null nel caso di accesso non avvenuto)
     */
    public FrameSel(boolean acc, String nick) {
        super("Selezione operazione");
        this.setSize(280, 200);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        String user = nick;
        JButton jb_ric = new JButton("Cerca");
        jb_ric.setCursor(new Cursor(12));
        JButton jb_info = new JButton("Vedi info");
        jb_info.setCursor(new Cursor(12));
        JButton jb_giud = new JButton("Giudica");
        jb_giud.setCursor(new Cursor(12));
        JButton jb_crea = new JButton("Crea play list");
        jb_giud.setCursor(new Cursor(12));

        
        if (acc == false) {
            jb_giud.setEnabled(false);
            jb_giud.setVisible(false);
            jb_crea.setEnabled(false);
            jb_crea.setVisible(false);

        }
        
        JPanel jp = new JPanel();
        jp.setLayout(new BoxLayout(jp, BoxLayout.X_AXIS));
        jp.add(jb_ric);
        jp.add(jb_info);
        jp.add(jb_giud);
        
        JPanel jp2 = new JPanel();
        jp2.setLayout(new BoxLayout(jp2, BoxLayout.X_AXIS));
        jp2.add(jb_crea);
    
        
        JPanel jp3 = new JPanel();
        jp3.setLayout(new BoxLayout(jp3, BoxLayout.Y_AXIS));
        jp3.setBorder(BorderFactory.createEmptyBorder(60, 0, 0, 0));
        jp3.add(jp);
        jp3.add(jp2);
        
        add(jp3, BorderLayout.CENTER);
        
        
        jb_ric.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {    
                FrameRicerca fr = new FrameRicerca();
                fr.setVisible(true);
                setVisible(false);
            }
        });
        
        jb_giud.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FrameSelCan fsg = new FrameSelCan(user, acc);
                fsg.setVisible(true);
                setVisible(false);
            }
        });
        
        jb_info.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FrameSelCan fsg = new FrameSelCan(user, acc);
                fsg.setVisible(true);
                setVisible(false);
            }
        });
        
            jb_crea.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FrameSelCan fsg = new FrameSelCan(user, acc);
                fsg.setVisible(true);
                setVisible(false);
            }
        });
           
    }
    
}
