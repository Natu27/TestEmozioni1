/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * Permette di eseguire l'accesso autenticandosi
 * (inserendo username e password utilizzati al 
 * momento della registrazione), di accedere
 * liberamente (senza autenticazione) o di registrarsi.
 */
public class MyFrameC extends JFrame{
    
    BufferedReader bf;
    String row;
    String[] split;
    boolean acc = false;
    
    /**
     * Contiene tutti gli elementi da visualizzare e
     * definisce alcune caratteristiche della pagina
     * come titolo, dimensione e comportamento alla chiusura
     */
    public MyFrameC(){
        super("Accesso Utenti");
        this.setSize(400, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        JLabel jl_Username = new JLabel("Username: ");
        jl_Username.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_Username = new RoundJtextField();
        jtf_Username.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JLabel jl_Passwd = new JLabel("Password: ");
        jl_Passwd.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JPasswordField jpf_Passwd = new RoundPassField();
        jpf_Passwd.setHorizontalAlignment(SwingConstants.CENTER);
        
        JButton btn_Acc = new JButton("Accedi");
        btn_Acc.setCursor(new Cursor(12));
        
        
        
        
        JPanel jp1 = new JPanel();
        jp1.setLayout(new BoxLayout(jp1, BoxLayout.Y_AXIS));
        jp1.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        jp1.add(jl_Username);
        jp1.add(jtf_Username);
        jp1.add(jl_Passwd);
        jp1.add(jpf_Passwd);
        
        
        
        JPanel jp1_5 = new JPanel();
        jp1_5.setBorder(BorderFactory.createEmptyBorder(10, 50, 30, 50));
        jp1_5.setLayout(new BorderLayout());
        jp1_5.add(jp1, BorderLayout.CENTER);
        jp1_5.add(btn_Acc, BorderLayout.SOUTH);
        
        getContentPane().add(jp1_5, BorderLayout.CENTER);
        
        
        
        JButton btn_Reg = new JButton("Registrati");
        btn_Reg.setCursor(new Cursor(12));
        JButton btn_AccLib = new JButton("Accesso libero");
        btn_AccLib.setCursor(new Cursor(12));
        
        JPanel jp2 = new JPanel();
        jp2.setLayout(new BoxLayout(jp2, BoxLayout.X_AXIS));
        jp2.setBorder(BorderFactory.createEmptyBorder(0, 90, 0, 0));
        jp2.add(btn_Reg);
        jp2.add(btn_AccLib);
        
        getContentPane().add(jp2, BorderLayout.SOUTH);
        
        
        
        btn_Reg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FrameReg fReg = new FrameReg();
                fReg.setVisible(true);
            }
        });
        
        btn_AccLib.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FrameSel fSel = new FrameSel(false, null);
                fSel.setVisible(true);
            }
        });
        
        btn_Acc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File f = new File("data/UtentiRegistrati.dati");
                String user = jtf_Username.getText();
                String psw = jpf_Passwd.getText();
                jtf_Username.setText("");
                jpf_Passwd.setText("");
                
                if (!f.exists()) {
                    System.err.println("IL FILE NON ESISTE");
                }
                
                try {
                    
                    bf = new BufferedReader(new FileReader(f));
                } catch (FileNotFoundException ex) {
                    System.err.println("ERRORE " + ex);
                }
                
                while (true) {                    
                    try {
                        row = bf.readLine();
                        split = row.split("/");
                        
                        if (split[5].equalsIgnoreCase(user) &&
                                split[6].equalsIgnoreCase(psw) &&
                                (!user.equals("") || (!psw.equals("")))) {
                            
                            acc = true;
                            FrameSel fs = new FrameSel(true, split[5]);
                            fs.setVisible(true);
                            
                        }
                        
                    } catch (IOException ex) {
                        System.err.println("ERRORE " + ex);
                        break;
                    } catch (NullPointerException ex) {
                        System.err.println("ERRORE " + ex);
                        break;
                    }
                }
                
                if (acc == false) {
                    JOptionPane.showMessageDialog(getContentPane(), "Credenziali errate");
                }
                
            }
        });
        
    }
    
}
