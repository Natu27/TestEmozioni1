/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FrameReg extends JFrame{
    
    /**
     * Contiene tutte le componenti da visualizzare e definisce le
     * caratteristiche della pagina.
     * Viene anche eseguita la scrittura su file del nuovo utente.
     * Inoltre crea il File UtentiRegistrati.dati se esso non esiste
     */
    public FrameReg() {
        super("Registrazione Clienti");
        this.setSize(400, 500);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        
        
        JLabel jl_nome = new JLabel("nome:");
        jl_nome.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_nome = new RoundJtextField();
        jtf_nome.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JLabel jl_cognome = new JLabel("cognome:");
        jl_cognome.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_cognome = new RoundJtextField();
        jtf_cognome.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JLabel jl_comune = new JLabel("comune:");
        jl_comune.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_comune = new RoundJtextField();
        jtf_comune.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JLabel jl_Prov = new JLabel("provincia:");
        jl_Prov.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        String[] jci_Prov = {"AG","AL","AN","AO","AQ","AR","AP","AT","AV","BA","BT","BL",
                             "BN","BG","BI","BO","BZ","BS","BR","CA","CL","CB","CI","CE",
                             "CT","CZ","CH","CO","CS","CR","KR","CN","EN","FM","FE","FI",
                             "FG","FC","FR","GE","GO","GR","IM","IS","SP","LT","LE","LC",
                             "LI","LO","LU","MC","MN","MS","MT","VS","ME","MI","MO","MB",
                             "NA","NO","NU","OG","OT","OR","PD","PA","PR","PV","PG","PU",
                             "PE","PC","PI","PT","PN","PZ","PO","RG","RA","RC","RE","RI",
                             "RN","ROMA","RO","SA","SS","SV","SI","SR","SO","TA","TE",
                             "TR","TO","TP","TN","TV","TS","UD","VA","VE","VB","VC","VR",
                             "VV","VI","VT"
        };
        JComboBox jc_Prov = new JComboBox(jci_Prov);
        
        
        
        JLabel jl_mail = new JLabel("mail:");
        jl_mail.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_mail = new RoundJtextField();
        jtf_mail.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JLabel jl_nick = new JLabel("nick name:");
        jl_nick.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField jtf_nick = new RoundJtextField();
        jtf_nick.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        
        JLabel jl_pass = new JLabel("password:");
        jl_pass.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JPasswordField jpf_pass = new RoundPassField();
        jpf_pass.setHorizontalAlignment(SwingConstants.CENTER);
        
        
        JButton jb_reg = new JButton("registrati");
        
        
        JPanel jp = new JPanel();
        jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
        jp.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));
        jp.add(jl_nome);
        jp.add(jtf_nome);
        jp.add(jl_cognome);
        jp.add(jtf_cognome);
        jp.add(jl_comune);
        jp.add(jtf_comune);
        jp.add(jl_Prov);
        jp.add(jc_Prov);
        jp.add(jl_mail);
        jp.add(jtf_mail);
        jp.add(jl_nick);
        jp.add(jtf_nick);
        jp.add(jl_pass);
        jp.add(jpf_pass);
        
        add(jp, BorderLayout.CENTER);
        
        JPanel jpb = new JPanel();
        jpb.setBorder(BorderFactory.createEmptyBorder(0, 35, 0, 50));
        jpb.add(jb_reg);
        
        add(jpb, BorderLayout.SOUTH);
        
        
        
        
        jb_reg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                File fc = new File("data/UtentiRegistrati.dati");
                
                if (!fc.exists()) {
                    try {
                        fc.createNewFile();
                    } catch (IOException ex) {
                        System.err.println("ERRORE: " + ex);
                    }
                }
                
                if (!jtf_nome.getText().equals("") &&
                        !jtf_cognome.getText().equals("") &&
                        !jtf_comune.getText().equals("") &&
                        !jtf_mail.getText().equals("") &&
                        !jtf_nick.getText().equals("") &&
                        !jpf_pass.getText().equals("")) {
                    
                    
                    Path p = Paths.get("data/UtentiRegistrati.dati");
                    try {
                        Files.write(p, jtf_nome.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jtf_cognome.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jtf_comune.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jc_Prov.getSelectedItem().toString().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jtf_mail.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jtf_nick.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, jpf_pass.getText().getBytes(), StandardOpenOption.APPEND);
                        Files.write(p, "\n".getBytes(), StandardOpenOption.APPEND);
                        
                        
                        jtf_nome.setText("");
                        jtf_cognome.setText("");
                        jtf_comune.setText("");
                        jtf_mail.setText("");
                        jtf_nick.setText("");
                        jpf_pass.setText("");
                        
                        
                        
                    } catch (IOException ex) {
                        System.err.println("ERRORE: " + ex);
                    }
                    
                } else {
                    JOptionPane.showMessageDialog(getContentPane(), "campo mancante");
                }
            }
        });
        
      
    }
    
}
