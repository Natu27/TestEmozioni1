/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 * Permette di visualizzare tutte le 
 * informazioni relative alla canzone selezionata
 * comprese le valutazioni dettagliate e il numero di
 * valutazioni numeriche divise per voto
 */
public class FrameInfo extends JFrame{
    
    BufferedReader bf;
    String row;
    String[] split;
    int i = 1;
    int[] vett_voti = {0,0,0,0,0};

    
    /**
     * Contiene tutti gli elementi presenti all'interno della 
     * finestra e definisce anche le principali caratteristiche
     * di tale finestra
     * 
     * @param pos posizione del canzone all'interno del file
     * contenente le informazioni delle canzoni
     */
    public FrameInfo(String pos) {
        super("Visualizza informazioni");
        this.setSize(550, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        
        JTextArea jta_info = new JTextArea();
        jta_info.setEditable(false);
        
        JScrollPane jsp = new JScrollPane(jta_info, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        
        File f = new File("data/Canzoni.dati");
        
        if (!f.exists()){
            System.err.println("IL FILE NON ESISTE");
        }
            
        try {
            bf = new BufferedReader(new FileReader(f));
        } catch (FileNotFoundException ex) {
            System.err.println("ERRORE " + ex);
        }
        
        while (true) {
            try {
                row = bf.readLine();
                split = row.split("/");
                
                if (i == Integer.parseInt(pos)) {
                    jta_info.setText(jta_info.getText() + "Titolo Canzone: ");
                    jta_info.setText(jta_info.getText() + split[3]);
                    jta_info.setText(jta_info.getText() + "\n");
                    jta_info.setText(jta_info.getText() + "Autore: ");
                    jta_info.setText(jta_info.getText() + split[2]);
                    jta_info.setText(jta_info.getText() + "\n");
                    jta_info.setText(jta_info.getText() + "Anno ");
                    jta_info.setText(jta_info.getText() + split[0]);
                    jta_info.setText(jta_info.getText() + "\n");
             
                } else {
                    if (split[1].equals(pos)) {
                        jta_info.setText(jta_info.getText() + "\n");
                        jta_info.setText(jta_info.getText() + "GIUDIZIO: ");
                        jta_info.setText(jta_info.getText() + "\n         ");
                        jta_info.setText(jta_info.getText() + "UTENTE: ");
                        jta_info.setText(jta_info.getText() + split[3]);
                        jta_info.setText(jta_info.getText() + "\n         ");
                        jta_info.setText(jta_info.getText() + "VOTO: ");
                        jta_info.setText(jta_info.getText() + split[5]);
                        jta_info.setText(jta_info.getText() + "\n         ");
                        jta_info.setText(jta_info.getText() + "CATEGORIA: ");
                        jta_info.setText(jta_info.getText() + split[4]);
                        jta_info.setText(jta_info.getText() + "\n         ");
                        jta_info.setText(jta_info.getText() + "DESCRIZIONE: ");
                        jta_info.setText(jta_info.getText() + split[6]);
                        jta_info.setText(jta_info.getText() + "\n");
                        
                        vett_voti[Integer.parseInt(split[5])-1]++;
                    }
                }
                i++;
            } catch (IOException ex) {
                System.err.println("ERRORE " + ex);
                break;
            } catch (NullPointerException ex) {
                System.err.println("ERRORE " + ex);
                break;
            }
        }
        
        for (int j = 0; j < 5; j++) {
            jta_info.setText(jta_info.getText() + "\n");
            jta_info.setText(jta_info.getText() + "VOTI CON VALORE " + (j+1) + ": " + vett_voti[j]);
        }
        
        jta_info.setCaretPosition(0);
        add(jsp, BorderLayout.CENTER);
    }
    
}
