/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienti;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import javax.swing.*;

/**
 * Permette di inserire giudizzi testuali e numerici
 * alle canzoni.
 */
public class FrameGiud extends JFrame {
    
    /**
     * Contiene tutte le componenti della finestra e ne 
     * definisce le principali componenti come dimensione
     * titolo e comportamento quando viene chiusa
     * 
     * @param nick nickname dell'utente che inserisce la valutazione
     * @param nCan nome della canzone che riceve la valutazione
     * @param pCan posizione della canzone all'interno del file
     * nel quale sono salvati tutte le canzoni e i rispettivi giudizi
     */
    public FrameGiud(String nick, String nCan, String pCan) {
        super("Inserisci giudizio");
        this.setSize(550, 300);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        
        String user = nick;
        JLabel jl_gnum = new JLabel(" Inserisci score ");
        
        String[] jc_emozioni = {"Amazement", "Solemnity", "Tenderness", "Nostalgia", "Calmness", "Power", 
                                "Joy", "Tension", "Sadness"};
        JComboBox jc_Em = new JComboBox(jc_emozioni); 
        
        
        String[] jc_items = {"1","2","3","4","5"};
        JComboBox jc = new JComboBox(jc_items);
        
        JPanel jp = new JPanel();
        jp.setLayout(new BoxLayout(jp, BoxLayout.X_AXIS));
        jp.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));
        jp.add(jc_Em);
        jp.add(jl_gnum);
        jp.add(jc);
        
        
        JLabel jl_gtxt = new JLabel("Inserisci note testuale: ");
        
        JTextArea jta_gtxt = new JTextArea(); 
        
        jta_gtxt.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (jta_gtxt.getText().length()%40 == 0 && 
                        jta_gtxt.getText().length() > 0) {
                    jta_gtxt.setText(jta_gtxt.getText() + "\n");
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (jta_gtxt.getText().length()%40 == 0 &&
                        jta_gtxt.getText().length() > 0) {
                    jta_gtxt.setText(jta_gtxt.getText() + "\n");
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        JPanel jp2 = new JPanel();
        jp2.setLayout(new BoxLayout(jp2, BoxLayout.Y_AXIS));
        jp2.setBorder(BorderFactory.createEmptyBorder(10, 100, 10, 100));
        jp2.add(jl_gtxt);
        jp2.add(jta_gtxt);
        
        JButton jb = new JButton("Salva giudizio");
        
        JPanel jp3 = new JPanel();
        jp3.setBorder(BorderFactory.createEmptyBorder(0, 50, 10, 50));
        jp3.add(jb);
        
        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File f = new File("data/Canzoni.dati");
                
                if (!f.exists()) {
                    System.err.println("IL FILE NON ESISTE");
                }
                
                Path p = Paths.get("data/Canzoni.dati");
                try {
                    
                    Files.write(p, "Giudizio".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, pCan.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, nCan.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, user.getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, jc_Em.getSelectedItem().toString().getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, jc.getSelectedItem().toString().getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "/".getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, jta_gtxt.getText().getBytes(), StandardOpenOption.APPEND);
                    Files.write(p, "\n".getBytes(), StandardOpenOption.APPEND);
                    
                } catch (IOException ex) {
                    System.err.println("ERRORE " + ex);
                }
                
                jta_gtxt.setText("");
                jc.setSelectedItem("1");
            }
        });
               
        add(jp, BorderLayout.NORTH);
        add(jp2, BorderLayout.CENTER);
        add(jp3, BorderLayout.SOUTH);
    }
    
}
